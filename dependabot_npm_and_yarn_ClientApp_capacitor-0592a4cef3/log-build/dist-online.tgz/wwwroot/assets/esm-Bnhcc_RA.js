const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-7sdJ1cI4.js","assets/index-C-sSKZzO.js","assets/index-C2Ic6LQI.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-C-sSKZzO.js";const o=r("Share",{web:()=>t(()=>import("./web-7sdJ1cI4.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
