const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BcUMVx1f.js","./index-5BhjlFyx.js","./index-SCJFQcpn.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-5BhjlFyx.js";const _=r("Share",{web:()=>t(()=>import("./web-BcUMVx1f.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
