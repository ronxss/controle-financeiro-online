const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CVXOZNdt.js","./index-BdpC2_fd.js","./index-SCJFQcpn.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BdpC2_fd.js";const _=r("Share",{web:()=>t(()=>import("./web-CVXOZNdt.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
