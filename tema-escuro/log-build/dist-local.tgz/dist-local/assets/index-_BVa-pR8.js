const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-gMO4KW8H.js","./index-C_fgtKAW.js","./index-SCJFQcpn.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-C_fgtKAW.js";const _=r("Share",{web:()=>t(()=>import("./web-gMO4KW8H.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
