// Gerado automaticamente por pwa-plugin.js. Não edite.
const CACHE = 'controle-financeiro-mwc4w0ul';
const ARQUIVOS = [
  "./",
  "assets/roboto-cyrillic-ext-300-normal-DIxttMbC.woff2",
  "assets/roboto-cyrillic-300-normal-DzUz0kzv.woff2",
  "assets/roboto-greek-300-normal-DJEM9B4Z.woff2",
  "assets/roboto-math-300-normal-5dF_7mZP.woff2",
  "assets/roboto-symbols-300-normal-DDU7avhj.woff2",
  "assets/roboto-vietnamese-300-normal-BPvXm_f1.woff2",
  "assets/roboto-latin-ext-300-normal-B90pq-BC.woff2",
  "assets/roboto-latin-300-normal-CCzlftfr.woff2",
  "assets/roboto-cyrillic-ext-400-normal-qHufge6k.woff2",
  "assets/roboto-cyrillic-400-normal-CBPI_iaY.woff2",
  "assets/roboto-greek-400-normal-ai2Z1K3C.woff2",
  "assets/roboto-math-400-normal-BEFej5gc.woff2",
  "assets/roboto-symbols-400-normal-CB1Ce4Gk.woff2",
  "assets/roboto-vietnamese-400-normal-D2PTxGxD.woff2",
  "assets/roboto-latin-ext-400-normal-C3tdtHj3.woff2",
  "assets/roboto-latin-400-normal-BqEyEoaF.woff2",
  "assets/roboto-cyrillic-ext-500-normal-BWC_xYeb.woff2",
  "assets/roboto-cyrillic-500-normal-CLao9AfR.woff2",
  "assets/roboto-greek-500-normal-C9AnhcmC.woff2",
  "assets/roboto-math-500-normal-C4NU9gLX.woff2",
  "assets/roboto-symbols-500-normal-B_CZKVJS.woff2",
  "assets/roboto-vietnamese-500-normal-B3ncpOoB.woff2",
  "assets/roboto-latin-ext-500-normal-pMCM9Ixg.woff2",
  "assets/roboto-latin-500-normal-7RbcRiD8.woff2",
  "assets/roboto-cyrillic-ext-700-normal-DmFxo5wj.woff2",
  "assets/roboto-cyrillic-700-normal-C2o7G-SM.woff2",
  "assets/roboto-greek-700-normal-0aHWxGLu.woff2",
  "assets/roboto-symbols-700-normal-BiFDindJ.woff2",
  "assets/roboto-math-700-normal-B8YqGHVc.woff2",
  "assets/roboto-vietnamese-700-normal-BEVeWqJt.woff2",
  "assets/roboto-latin-ext-700-normal-DSBUz0N1.woff2",
  "assets/roboto-latin-700-normal-BZpUvMxY.woff2",
  "assets/index-SCJFQcpn.css",
  "assets/index-Bd5XY3XW.js",
  "assets/esm-DNTp1XYi.js",
  "assets/esm-DN0tBFFn.js",
  "assets/esm-DNf77P7Y.js",
  "assets/web-m4btt5n2.js",
  "assets/web-BONj8U4L.js",
  "assets/web-CuezzMPs.js",
  "icons/apple-touch-icon.png",
  "icons/icon-192.png",
  "icons/icon-512.png",
  "icons/maskable-512.png",
  "manifest.webmanifest"
];

self.addEventListener('install', (evento) => {
  evento.waitUntil(
    caches.open(CACHE)
      .then((cache) => cache.addAll(ARQUIVOS.map((url) => new Request(url, { cache: 'reload' }))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (evento) => {
  evento.waitUntil(
    caches.keys()
      .then((nomes) => Promise.all(nomes.filter((n) => n.startsWith('controle-financeiro-') && n !== CACHE).map((n) => caches.delete(n))))
      .then(() => self.clients.claim())
  );
});

// Cache primeiro: tudo que é do app vem do aparelho. Se faltar algo e não houver internet,
// páginas abrem o index.html (o app inteiro roda dentro dele).
self.addEventListener('fetch', (evento) => {
  const pedido = evento.request;
  if (pedido.method !== 'GET') return;
  if (new URL(pedido.url).origin !== self.location.origin) return;

  evento.respondWith(
    caches.open(CACHE).then(async (cache) => {
      const guardado = await cache.match(pedido, { ignoreSearch: true });
      if (guardado) return guardado;
      try {
        return await fetch(pedido);
      } catch (erro) {
        if (pedido.mode === 'navigate') {
          const inicio = await cache.match('./index.html');
          if (inicio) return inicio;
        }
        throw erro;
      }
    })
  );
});
